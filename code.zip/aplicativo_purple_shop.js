onEvent("volt1", "click", function( ) {
  setScreen("1Inicio");
});
onEvent("bLogin", "click", function( ) {
  setScreen("4Categorias");
});
onEvent("bRegistrar", "click", function( ) {
  setScreen("3Cad");
});
onEvent("volt2", "click", function( ) {
  setScreen("1Inicio");
});
onEvent("button3", "click", function() {
  setScreen("4Categorias");
});
onEvent("CatPlacadevideo", "click", function( ) {
  setScreen("5Placasdevideo");
});
onEvent("button5", "click", function( ) {
  setScreen("4Categorias");
});
onEvent("CatProcessadores", "click", function( ) {
  setScreen("6Processadores");
});
onEvent("button12", "click", function( ) {
  setScreen("4Categorias");
});
onEvent("CatPlacamae", "click", function( ) {
  setScreen("7Placasmaes");
});
onEvent("button6", "click", function( ) {
  setScreen("4Categorias");
});
onEvent("CatGeral", "click", function( ) {
  setScreen("8Perifericos");
});
onEvent("8Perife", "click", function( ) {
  setScreen("4Categorias");
});
onEvent("button2", "click", function( ) {
  setScreen("carrinho");
});
onEvent("volta", "click", function( ) {
  setScreen("4Categorias");
});

onEvent("AMD67XT", "click", function( ) {
  setScreen("páginaAMD67XT");
});
onEvent("button21", "click", function( ) {
  setScreen("5Placasdevideo");
});
onEvent("rtx2060", "click", function( ) {
  setScreen("páginartx2060");
});
onEvent("button9", "click", function( ) {
  setScreen("5Placasdevideo");
});
onEvent("RTX3060", "click", function( ) {
  setScreen("páginaRTX3060");
});
onEvent("button4", "click", function( ) {
  setScreen("5Placasdevideo");
});
onEvent("GTX1660", "click", function( ) {
  setScreen("páginaGTX1660");
});
onEvent("button15", "click", function( ) {
  setScreen("5Placasdevideo");
});

onEvent("INT510", "click", function( ) {
  setScreen("páginaINT510");
});
onEvent("button27", "click", function( ) {
  setScreen("6Processadores");
});
onEvent("INT910", "click", function( ) {
  setScreen("páginaINT910");
});
onEvent("button29", "click", function( ) {
  setScreen("6Processadores");
});
onEvent("RZ95950", "click", function( ) {
  setScreen("páginaRZ95950");
});
onEvent("button25", "click", function( ) {
  setScreen("6Processadores");
});
onEvent("RZ55600", "click", function( ) {
  setScreen("páginaRZ55600");
});
onEvent("button23", "click", function( ) {
  setScreen("6Processadores");
});
;
onEvent("B450M", "click", function( ) {
  setScreen("páginaB450M");
});
onEvent("button35", "click", function( ) {
  setScreen("7Placasmaes");
});
onEvent("B550-P", "click", function( ) {
  setScreen("páginaB550-P");
});
onEvent("button37", "click", function( ) {
  setScreen("7Placasmaes");
});
onEvent("B550M", "click", function( ) {
  setScreen("páginaB550M");
});
onEvent("button31", "click", function( ) {
  setScreen("7Placasmaes");
});
onEvent("H510M-E", "click", function( ) {
  setScreen("páginaH510M");
});
onEvent("button33", "click", function( ) {
  setScreen("7Placasmaes");
});
;
onEvent("button10", "click", function( ) {
  setScreen("páginaGabinete");
});
onEvent("button45", "click", function( ) {
  setScreen("8Perifericos");
});
onEvent("button11", "click", function( ) {
  setScreen("páginaTeclado");
});
onEvent("button41", "click", function( ) {
  setScreen("8Perifericos");
});
onEvent("button8", "click", function( ) {
  setScreen("páginaMouse");
});
onEvent("button39", "click", function( ) {
  setScreen("8Perifericos");
});
onEvent("button13", "click", function( ) {
  setScreen("páginaHeadset");
});
onEvent("button43", "click", function( ) {
  setScreen("8Perifericos");
});
;
